#!/usr/bin/python3
#coding=utf-8
import math
import sys
import datetime
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net  import F3Net
from apex import amp
import numpy as np
from dfl import DFL
import cv2
import os

def UFL(outputs, labels, epoch, step):
    loss_CE = F.binary_cross_entropy_with_logits(outputs, labels, reduce='none')
    #loss_CE = loss_CE.mean()
    p = torch.sigmoid(outputs)
    p = p.permute(0, 2, 3, 1).contiguous().view(-1, 1)
    labels = labels.permute(0, 2, 3, 1).contiguous().view(-1, 1)
    #w1 = 4
    w1 = 1.5+0.5 * np.sin((epoch + 1) * math.pi / 64)
    chen11 = w1 - w1 / (1 + torch.exp(-10 * (p - 0.5))) + w1-w1*(p**2)
    #chen11 = 5*torch.exp(-5 * (p - 0.5)) / ((1 + torch.exp(-5 * (p - 0.5)))**2)
    chen11 = chen11 * labels
    chen12 = w1 / (1 + torch.exp(-10 * (p - 0.5))) + w1-w1*((1-p)**2)
    #chen12 = 5 * torch.exp(-5 * (p - 0.5)) / ((1 + torch.exp(-5 * (p - 0.5))) ** 2)
    chen12 = chen12 * (1-labels)
    chen0 = chen11 + chen12
    """
    b1 = p * labels + 1*(1-labels)
    #b1 = p * labels
    chen11 = w1 - w1 / (1 + torch.exp(-10 * (b1 - 0.5)))
    b2 = p * (1-labels)
    chen12 = w1 / (1 + torch.exp(-10 * (b2 - 0.5)))   
    loss1 = (1 ** 2) * torch.mean(torch.sum(chen11, dim=1))
    loss2 = (1 ** 2) * torch.mean(torch.sum(chen12, dim=1))
    """
    loss0 = (1 ** 2) * torch.mean(torch.sum(chen0, dim=1))
    KD_loss = loss_CE + loss0
    return KD_loss

def UAL(outputs, labels, epoch, step):
    loss_CE = F.binary_cross_entropy_with_logits(outputs, labels, reduce='none')
    #loss_CE = loss_CE.mean()
    p = torch.sigmoid(outputs)
    p = p.permute(0, 2, 3, 1).contiguous().view(-1, 1)
    labels = labels.permute(0, 2, 3, 1).contiguous().view(-1, 1)
    b3 = p
    chen13 =1*(4*b3-4*(b3**2))
    loss3 = (1 ** 2) * torch.mean(torch.sum(chen13, dim=1))
    # # KD_loss = (1. - alpha)*loss_CE + alpha*loss_soft_regu
    KD_loss = loss_CE + loss3

    return KD_loss

def train(Dataset, Network, i):
    ## dataset
    aloss = UFL
    cfg    = Dataset.Config(datapath='/home/chen/Downloads/code/2022segmentation_upload/src/data/ExpData/Train/' + i + '/', savepath='./IAL/', mode='train', batch=32, lr=0.05, momen=0.9, decay=5e-4, epoch=32)
    data   = Dataset.Data(cfg)
    loader = DataLoader(data, collate_fn=data.collate, batch_size=cfg.batch, shuffle=True, num_workers=8)
    ## network
    net    = Network(cfg)
    net.train(True)
    net.cuda()
    ## parameter
    base, head = [], []
    for name, param in net.named_parameters():
        if 'bkbone.conv1' in name or 'bkbone.bn1' in name:
            print(name)
        elif 'bkbone' in name:
            base.append(param)
        else:
            head.append(param)
    optimizer      = torch.optim.SGD([{'params':base}, {'params':head}], lr=cfg.lr, momentum=cfg.momen, weight_decay=cfg.decay, nesterov=True)
    net, optimizer = amp.initialize(net, optimizer, opt_level='O2')
    sw             = SummaryWriter(cfg.savepath)
    global_step    = 0
    #structure_loss = FL()
    structure_loss = aloss
    for epoch in range(cfg.epoch):
        optimizer.param_groups[0]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr*0.1
        optimizer.param_groups[1]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr

        for step, (image, mask) in enumerate(loader):
            image, mask = image.cuda().float(), mask.cuda().float()
            out1u, out2u, out2r, out3r, out4r, out5r = net(image)


            loss1u = structure_loss(out1u, mask, epoch, step)
            loss2u = structure_loss(out2u, mask, epoch, step)

            loss2r = structure_loss(out2r, mask, epoch, step)
            loss3r = structure_loss(out3r, mask, epoch, step)
            loss4r = structure_loss(out4r, mask, epoch, step)
            loss5r = structure_loss(out5r, mask, epoch, step)

            loss   = (loss1u+loss2u)/2+loss2r/2+loss3r/4+loss4r/8+loss5r/16
            #loss = structure_loss(out2u, mask, epoch, step)
            optimizer.zero_grad()
            with amp.scale_loss(loss, optimizer) as scale_loss:
                scale_loss.backward()
            optimizer.step()

            ## log
            global_step += 1
            #sw.add_scalar('lr'   , optimizer.param_groups[0]['lr'], global_step=global_step)
            #sw.add_scalars('loss', {'loss':loss.item(),'loss1u':loss1u.item(), 'loss2u':loss2u.item(), 'loss2r':loss2r.item(), 'loss3r':loss3r.item(), 'loss4r':loss4r.item(), 'loss5r':loss5r.item()}, global_step=global_step)
            #sw.add_scalars('loss', {'loss': loss.item()}, global_step=global_step)

            if step%10 == 0:
                print('%s | step:%d/%d/%d | lr=%.6f | loss=%.6f'%(datetime.datetime.now(), global_step, epoch+1, cfg.epoch, optimizer.param_groups[0]['lr'], loss.item()))

        if (epoch+1)==cfg.epoch:
            torch.save(net.state_dict(), cfg.savepath+'/UAL'+ i)



if __name__=='__main__':
    #a = (CE, DCE, FL, DFL, WCE, OUR)
    #i = IAL
    #train(dataset, F3Net, i)
    a = {'THUR','SOC','COD','DUT-OMROM','PASCAL-S'}
    #a = {'DUT-OMROM','COD'}
    #a = {'THUR', 'DUT-OMROM', 'SOC', 'COD'}
    #a = {'PASCAL-S'}
    #a = {'HKU'}
    for i in a:
        train(dataset, F3Net, i)

