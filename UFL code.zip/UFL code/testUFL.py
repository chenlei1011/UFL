#!/usr/bin/python3
# coding=utf-8

import os
import sys

sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import cv2
import numpy as np
import matplotlib.pyplot as plt

plt.ion()

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net import F3Net


def structure_loss(pred, mask):
    # CE
    nwbce = F.binary_cross_entropy_with_logits(pred, mask, reduction='none')

    loss = nwbce.mean()
    return loss


class Test(object):
    def __init__(self, Dataset, Network, path, i):
        ## dataset
        self.cfg = Dataset.Config(datapath=path,
                                  snapshot='/home/chen/Downloads/code/F3Net-master/src/IAL/UAL'+i,
                                  savepath='./IAL/eval', mode='test')
        self.data = Dataset.Data(self.cfg)
        self.loader = DataLoader(self.data, batch_size=1, shuffle=False, num_workers=8)
        ## network
        self.net = Network(self.cfg)
        self.net.train(False)
        self.net.cuda()
        self.net.eval()
        self.i = i

    def save(self):
        #sw = SummaryWriter(self.cfg.savepath)
        #global_step = 0
        with torch.no_grad():
            for image, mask, shape, name in self.loader:
                image = image.cuda().float()
                out1u, out2u, out2r, out3r, out4r, out5r = self.net(image, shape)
                out = out2u
                #mask = mask.cuda().float()
                #mask = mask.unsqueeze(0)
                #loss = structure_loss(out, mask)
                pred = (torch.sigmoid(out[0, 0]) * 255).cpu().numpy()
                head = '/home/chen/Downloads/code/F3Net-master/src/IAL/eval/UAL' + self.i

                #global_step += 1
                #sw.add_scalars('F', {'loss': loss.item()}, global_step=global_step)
                if not os.path.exists(head):
                    os.makedirs(head)
                cv2.imwrite(head + '/' + name[0] + '.png', np.round(pred))


if __name__ == '__main__':
    """
    for path in ['/home/chen/Downloads/code/2022segmentation_upload/src/data/ExpData/Test/COD']:
        a = ('CODIAL')
        for i in a:
            t = Test(dataset, F3Net, path, i)
            t.save()
    """
    #a = {'THUR','DUT-OMROM','SOC','COD'}
    #a = {'DUT-OMROM','COD'}
    #a = {'THUR', 'DUT-OMROM'}
    #a = {'DUT-OMROM', 'SOC','COD'}
    #a = {'THUR','SOC','COD','DUT-OMROM','PASCAL-S'}
    #a = { 'SOC', 'COD'}
    a = {'PASCAL-S'}
    for i in a:
        path = '/home/chen/Downloads/code/2022segmentation_upload/src/data/ExpData/Test/' + i + '/'
        t = Test(dataset, F3Net, path, i)
        t.save()
